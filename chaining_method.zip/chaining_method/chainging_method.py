
class User:
    def __init__(self, name, email_address):
        self.name = name
        self.email = email_address
        self.account_balance = 0
    def make_deposit(self,amount):
        self.account_balance+= amount
        return self
    def make_withdrawl(self, amount):
        self.account_balance -= amount
        return self
    def display_user_balance(self):
        print(self.name, self.account_balance)
        return self
    def transfer_money(self, other_user, amount):
        self.account_balance -= amount
        other_user.account_balance += amount
        return self

guido = User("Guido van Rossum", "guido@python.com")
monty = User("Monty Python", "monty@python.com")
fred = User("Fred Flintsotne", "fred@bedrockquary.com")
guido.make_deposit(100).make_deposit(200).transfer_money(monty,100).display_user_balance()
fred.make_deposit(500).transfer_money(guido, 350).display_user_balance()
monty.make_deposit(50).display_user_balance()
# guido.make_deposit(100).display_user_balance()