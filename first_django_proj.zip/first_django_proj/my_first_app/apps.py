from django.apps import AppConfig


class MyFirstAppConfig(AppConfig):
    name = 'my_first_app'
