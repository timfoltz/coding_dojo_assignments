from django.shortcuts import render, HttpResponse, redirect

def index(request):
    
    num_visits = request.session.get('num_visits',1)
    request.session['num_visits'] = num_visits + 1
    context ={
        'num_visits':num_visits,
    }
    
    return render(request, "index.html", context)
    
def destroy_session(request):
    num_visits = request.session.get('num_visits',1)
    request.session['num_visits'] = 1

    return redirect("/")

def plus_two(request):
    num_visits = request.session.get('num_visits',1)
    request.session['num_visits'] = num_visits + 1

    return redirect("/")
# Create your views here.
