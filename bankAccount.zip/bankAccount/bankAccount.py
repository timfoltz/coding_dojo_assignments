class BankAccount:
    def __init__(self, int_rate, balance):
        self.interest_rate = int_rate
        self.account_balance = balance
    def deposit(self, amount):
        self.account_balance += amount
        return self
    def withdraw(self, amount):
        self.account_balance -= amount
        return self
    def display_account_info(self):
        print(self.account_balance)
        return self
    def yield_interest(self):
        self.account_balance = self.account_balance + ((self.interest_rate *1) * self.account_balance)
        return self

sparky = BankAccount(0.05, 200)
rusty = BankAccount(0.03, 100)


sparky.deposit(100).deposit(200).deposit(50).yield_interest().display_account_info()

rusty.deposit(200).deposit(300).withdraw(100).withdraw(50).withdraw(50).withdraw(100).yield_interest().display_account_info()