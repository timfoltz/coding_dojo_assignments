class User:
    def __init__(self, name, email_address):
        self.name = name
        self.email = email_address
        self.account = BankAccount(int_rate=0.02, balance=0)
    def make_deposit(self,amount):
        self.account.balance+= amount
        return self
    def make_withdrawl(self, amount):
        self.account -= amount
        return self
    def display_user_balance(self):
        print(self.name, self.account.balance)
        return self
    def transfer_money(self, other_user, amount):
        self.account.balance -= amount
        other_user.account.balance += amount
        return self

class BankAccount:
    def __init__(self, int_rate, balance):
        self.interest_rate = int_rate
        self.balance = balance
    def deposit(self, amount):
        self.balance += amount
        return self
    def withdraw(self, amount):
        self.balance -= amount
        return self
    def display_account_info(self):
        print(self.balance)
        return self
    def yield_interest(self):
        self.balance = self.balance + ((self.interest_rate *1) * self.balance)
        return self




guido = User("Guido van Rossum", "guido@python.com")
monty = User("Monty Python", "monty@python.com")
fred = User("Fred Flintsotne", "fred@bedrockquary.com")
wilma = User("Wilma Flintsone", "hotmama@bedrocksocial.com")

guido.make_deposit(105).make_deposit(200).transfer_money(monty,100).display_user_balance()
fred.make_deposit(500).transfer_money(guido, 350).display_user_balance()
monty.make_deposit(50).display_user_balance()
guido.account.deposit(100).deposit(100)
guido.display_user_balance()
wilma.display_user_balance().account.deposit(100)
wilma.display_user_balance()

# guido.make_deposit(100).display_user_balance()

# guido = BankAccount()
# monty = BankAccount(0.03, 100)


# guido.deposit(100).deposit(200).deposit(50).yield_interest().display_account_info()

# guido.deposit(200).deposit(300).withdraw(100).withdraw(50).withdraw(50).withdraw(100).yield_interest().display_account_info()
