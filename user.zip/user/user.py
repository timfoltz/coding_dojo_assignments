
class User:
    def __init__(self, name, email_address):
        self.name = name
        self.email = email_address
        self.account_balance = 0
    def make_deposite(self,amount):
        self.account_balance+= amount
    def make_withdrawl(self, amount):
        self.account_balance -= amount
    def display_user_balance(self):
        print(self.name, self.account_balance)
    def transfer_money(self, other_user, amount):
        self.account_balance -= amount
        other_user.account_balance += amount

guido = User("Guido van Rossum", "guido@python.com")
monty = User("Monty Python", "monty@python.com")
fred = User("Fred Flintsotne", "fred@bedrockquary.com")
guido.make_deposite(100)
guido.make_deposite(200)
monty.make_deposite(50)
fred.make_deposite(500)

print(guido.account_balance)
print(monty.account_balance)

guido.display_user_balance()
monty.display_user_balance()
fred.display_user_balance()

guido.transfer_money(monty,100)
fred.transfer_money(guido, 350)
guido.display_user_balance()
monty.display_user_balance()
fred.display_user_balance()
