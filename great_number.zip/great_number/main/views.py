from django.shortcuts import render, HttpResponse, redirect
# import random
def index(request):
    import random
    num_visits = request.session.get('num_visits',0)
    print("******************************hello*******************************")
    # num_visits = 0
    print(num_visits)
    if num_visits == 0:
        ran_num = random.randint(1, 100)
        request.session['random_num'] = ran_num
        print(f"random num  {ran_num}")
        
        num_visits = 1
        print(num_visits)
        return render(request, "index.html")
    else:
        return render(request, "index.html")

def guess(request):
    guess_from_form = int(request.POST['guess'])
    ran_num = int(request.session.get('random_num'))
    too_high = "Too High"
    correct = "Correct"
    too_low = "Too Low"
    print(guess_from_form)
    if guess_from_form == ran_num:
        print(ran_num)
        print("*************correct******************")
        correct_guess = {
            "correct" : correct
        }
        return render(request, "index.html", correct_guess)
        
    if guess_from_form < ran_num:
        print(ran_num)
        print("*************Too Low******************")
        this_guess = {
            "too_low" : too_low
        }
        return render(request, "index.html", this_guess)
        
    if guess_from_form > ran_num:
        print(ran_num)
        print("*************Too High******************")
        this_guess = {
            "too_low" : too_high
        }
        return render(request, "index.html", this_guess)
def reset(request):
    num_visits = request.session.get('num_visits',0)
    request.session['num_visits'] = 0
    return redirect("/")