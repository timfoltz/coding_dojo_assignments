from django.shortcuts import render, HttpResponse, redirect


def index(request):
    return render(request, "index.html")

def submitted_info(request):
    if request.method == "POST":
        val_from_name = request.POST["name"]
        val_from_email = request.POST["two"]
        print("a POST req is being made to this route")

def create_user(request):
    print("got post info *********************************")
    name_from_form = request.POST['name']
    email_from_form = request.POST['email']
    context = {
        "name_on_template" : name_from_form,
        "email_on_template" : email_from_form,
    }
    return render(request, "show_user.html", context)
# Create your views here.
