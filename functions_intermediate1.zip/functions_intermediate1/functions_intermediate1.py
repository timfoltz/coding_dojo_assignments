import random
def randInt(min=0, max=100):
    num = random.random() *(max - min) + min
    return round(num)
print(randInt(min=50, max=500))
